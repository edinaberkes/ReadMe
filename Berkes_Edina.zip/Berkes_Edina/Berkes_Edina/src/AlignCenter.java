public class AlignCenter implements AlignStrategy {

	public void print(String text) {
	 System.out.println("    CENTER:Text: "+text);
	 
		
	}
}