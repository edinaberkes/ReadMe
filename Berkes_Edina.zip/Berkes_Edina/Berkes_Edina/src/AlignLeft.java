public class AlignLeft implements AlignStrategy {

	public void print(String text) {
		System.out.println("LEft:Text: "+text);
		
	}

}
