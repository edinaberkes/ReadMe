public class AlignRight implements AlignStrategy{

	public void print(String text ) {
		System.out.println("      RIGHT=Text: "+text);
		
	}

}
