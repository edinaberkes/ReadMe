public interface AlignStrategy {
  public void print(String text);
}
