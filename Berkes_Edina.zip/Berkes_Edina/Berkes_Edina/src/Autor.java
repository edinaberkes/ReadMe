public class Autor {
	private String nume;

	public Autor(String nume) {
		super();
		this.nume = nume;
	}
	
	public String print()
	{
		return this.nume;
	}
}
