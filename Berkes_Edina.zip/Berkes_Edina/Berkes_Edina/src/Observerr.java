public interface Observerr {
	public void update(String oldValue,String newValue);
}
