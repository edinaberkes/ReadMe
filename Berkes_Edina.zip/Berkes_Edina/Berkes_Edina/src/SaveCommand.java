public class SaveCommand  implements Command{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
