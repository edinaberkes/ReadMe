package dp_lab2;

public class DocumentManager {

	public static Object getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
